Author: Nicolas Blanchard
Contact: (520) 834-3191 | nickyblanch@arizona.edu

Run 'main.m' to apply each filter and see the results!
Parameters and input image are controlled within 'main.m'.

See comments within code for details.